# Noise fingerprinting - ablations in one notebook
1. `pip install -r requirements.txt`
2. Open `noise_fingerprinting_ablations.ipynb` (keep it next to `datasets/`) and run top to bottom.
3. First code cell: `QUICK = True` is a ~7 min demo; `QUICK = False` gives the paper's full settings.
`scripts/` holds the same code as separate .py files (one per ablation) if you prefer the terminal.
