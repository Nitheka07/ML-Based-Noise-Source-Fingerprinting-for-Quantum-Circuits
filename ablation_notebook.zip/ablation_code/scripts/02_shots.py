"""
ABLATION 1 - SHOTS PER EXPERIMENT.
Question: does measuring each circuit more times (more shots) make the noise easier to identify?
Varied  : shots = 50 ... 32768 (12 values). Rows stay at 720; each row's probabilities get less noisy.
Run:  python 02_shots.py [--quick]
"""
from common import *
rows, by_sev = [], []
for s in SHOTS_LIST:
    for d in DRAWS:
        for sd in SEEDS:
            df = load(s, d)
            for m in MODELS:
                ok = cv_correct(df, model=m, seed=sd)
                rows.append(dict(shots=s, model=m, acc=ok.mean()))
                if m == "RF":                                    # accuracy by noise strength (RF only)
                    for sev, v in df.assign(_ok=ok).groupby("severity")["_ok"].mean().items():
                        by_sev.append(dict(shots=s, severity=sev, acc=v))
report(rows, ["shots", "model"], "02_shots_by_model")
report(by_sev, ["shots", "severity"], "02_shots_rf_by_severity")
