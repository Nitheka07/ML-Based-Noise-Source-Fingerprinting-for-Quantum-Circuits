"""
ABLATION 3a - NOISE-STRENGTH RANGE.
Question: is the model failing mostly on very weak noise?
Method  : keep only rows with severity >= threshold (drop the weakest levels), RF, 2048 shots.
Run:  python 04_severity_range.py [--quick]
"""
from common import *
rows = []
for th in SEVERITIES[:-1]:                               # 0.001, 0.005, 0.01, 0.02, 0.03
    for d in DRAWS:
        for sd in SEEDS:
            df = load(2048, d).query("severity >= @th").reset_index(drop=True)
            rows.append(dict(min_severity=th, n_rows=len(df), acc=cv_acc(df, model="RF", seed=sd)))
report(rows, ["min_severity", "n_rows"], "04_severity_range")
