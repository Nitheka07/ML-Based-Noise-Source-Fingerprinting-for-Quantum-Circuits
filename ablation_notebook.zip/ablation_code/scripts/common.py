"""
common.py  --  shared helpers used by every ablation script.

Contains:  (1) the 5 circuits   (2) the 4 noise models   (3) feature extraction
           (4) dataset generation  (5) the 5 classifiers + cross-validation
           (6) a tiny table printer.

You do NOT need to read this file to understand an ablation; each ablation file
(02_shots.py, 03_rows.py, ...) is short and only calls these helpers.
"""
import sys, warnings
from itertools import product
from pathlib import Path
import numpy as np, pandas as pd
warnings.filterwarnings("ignore")

HERE = Path(__file__).parent
DATA, RES = HERE.parent / "datasets", HERE.parent / "results"
RES.mkdir(exist_ok=True)

# ---- run modes:  python 02_shots.py            -> full (3 datasets x 2 CV seeds)
#                  python 02_shots.py --quick    -> fast check (1 dataset x 1 seed)
QUICK = "--quick" in sys.argv
DRAWS = [0] if QUICK else [0, 1, 2]     # which of the 3 independent datasets to use
SEEDS = [0] if QUICK else [0, 1]        # cross-validation shuffling seeds

# ---- experiment grid (5 x 4 x 6 x 6 = 720 rows per dataset)
SEVERITIES  = [0.001, 0.005, 0.01, 0.02, 0.03, 0.05]
NOISE_TYPES = ["depolarizing", "amplitude_damping", "phase_damping", "readout_error"]
CIRC_ORDER  = ["bell", "ghz", "w_state", "ghz4", "bell_pairs"]
SHOTS_LIST  = [50, 100, 200, 400, 600, 720, 1024, 2048, 4096, 8192, 16384, 32768]
META = ["circuit", "noise_type", "severity", "trial"]
ENG  = ["tvd", "entropy", "zero_bias", "unexpected_bitstring_rate",
        "symmetric_swap_rate", "parity_violation_rate"]          # 6 engineered features
MODELS = ["RF", "XGB", "SVM", "MLP", "LR"]


# =====================================================================
# 1. Circuits  (each returns the circuit and its ideal outcome distribution)
# =====================================================================
def _bell():
    from qiskit import QuantumCircuit
    qc = QuantumCircuit(2, 2); qc.h(0); qc.cx(0, 1); qc.measure([0, 1], [0, 1])
    return qc, {"00": .5, "11": .5}
def _ghz():
    from qiskit import QuantumCircuit
    qc = QuantumCircuit(3, 3); qc.h(0); qc.cx(0, 1); qc.cx(1, 2); qc.measure([0, 1, 2], [0, 1, 2])
    return qc, {"000": .5, "111": .5}
def _w_state():
    from qiskit import QuantumCircuit
    qc = QuantumCircuit(3, 3); qc.ry(1.9106332362490184, 0); qc.ch(0, 1); qc.cx(1, 2); qc.cx(0, 1); qc.x(0)
    qc.measure([0, 1, 2], [0, 1, 2])
    return qc, {"001": 1/3, "010": 1/3, "100": 1/3}
def _ghz4():
    from qiskit import QuantumCircuit
    qc = QuantumCircuit(4, 4); qc.h(0); qc.cx(0, 1); qc.cx(1, 2); qc.cx(2, 3); qc.measure(range(4), range(4))
    return qc, {"0000": .5, "1111": .5}
def _bell_pairs():
    from qiskit import QuantumCircuit
    qc = QuantumCircuit(4, 4); qc.h(0); qc.cx(0, 1); qc.h(2); qc.cx(2, 3); qc.measure(range(4), range(4))
    return qc, {"0000": .25, "0011": .25, "1100": .25, "1111": .25}

def circuits():
    return {"bell": _bell(), "ghz": _ghz(), "w_state": _w_state(), "ghz4": _ghz4(), "bell_pairs": _bell_pairs()}


# =====================================================================
# 2. Noise models (p = noise strength / severity)
# =====================================================================
def noise_model(kind, p, n_qubits):
    from qiskit_aer.noise import (NoiseModel, depolarizing_error, amplitude_damping_error,
                                  phase_damping_error, ReadoutError)
    nm, one_q, two_q = NoiseModel(), ["h", "x", "id", "ry"], ["cx", "ch"]
    if kind == "depolarizing":
        nm.add_all_qubit_quantum_error(depolarizing_error(p, 1), one_q)
        nm.add_all_qubit_quantum_error(depolarizing_error(p, 2), two_q)
    elif kind in ("amplitude_damping", "phase_damping"):
        e = amplitude_damping_error(p) if kind == "amplitude_damping" else phase_damping_error(p)
        nm.add_all_qubit_quantum_error(e, one_q)
        nm.add_all_qubit_quantum_error(e.tensor(e), two_q)
    else:  # readout_error: each measured bit flips with probability p
        ro = ReadoutError([[1 - p, p], [p, 1 - p]])
        for q in range(n_qubits): nm.add_readout_error(ro, [q])
    return nm


# =====================================================================
# 3. Features computed from the measurement counts only
# =====================================================================
def _probs(counts, n):
    tot = sum(counts.values())
    return {"".join(b): counts.get("".join(b), 0) / tot for b in product("01", repeat=n)}

def features(counts, ideal, n):
    pr = _probs(counts, n); full = {s: ideal.get(s, 0.0) for s in pr}
    tvd = 0.5 * sum(abs(pr[s] - full[s]) for s in pr)                       # distance from ideal
    ent = -sum(p * np.log2(p) for p in pr.values() if p > 0)                # Shannon entropy
    zfrac = lambda d: sum(p * (s.count("0") / n) for s, p in d.items())
    support = set(ideal)
    unexp = sum(p for s, p in pr.items() if s not in support)               # prob. of 'impossible' outcomes
    comp = lambda s: "".join("1" if c == "0" else "0" for c in s)
    seen, bal = set(), 0.0
    for s in pr:
        if s in support or s in seen: continue
        c = comp(s); seen.update([s, c])
        if c in support: continue
        bal += 2 * min(pr[s], pr.get(c, 0.0))
    par = lambda d: sum(p for s, p in d.items() if s.count("1") % 2 == 0)
    pe, ie = par(pr), par(full)
    return {"tvd": tvd, "entropy": ent, "zero_bias": zfrac(pr) - zfrac(full),
            "unexpected_bitstring_rate": unexp,
            "symmetric_swap_rate": bal / unexp if unexp > 1e-9 else 0.0,
            "parity_violation_rate": 0.5 * (abs(pe - ie) + abs((1 - pe) - (1 - ie)))}, pr


# =====================================================================
# 4. Dataset generation (only needed if you want to regenerate the CSVs)
# =====================================================================
def generate_dataset(shots, draw, trials=6):
    from qiskit import transpile
    from qiskit_aer import AerSimulator
    rows = []
    for ci, cname in enumerate(CIRC_ORDER):
        qc, ideal = circuits()[cname]; n = qc.num_qubits
        for ni, nt in enumerate(NOISE_TYPES):
            for si, sev in enumerate(SEVERITIES):
                sim = AerSimulator(noise_model=noise_model(nt, sev, n)); tqc = transpile(qc, sim)
                for trial in range(trials):
                    seed = (draw * 1000003 + ci * 10007 + ni * 1009 + si * 101 + trial * 7 + shots) % (2**31 - 1)
                    counts = sim.run(tqc, shots=shots, seed_simulator=seed).result().get_counts()
                    f, pr = features(counts, ideal, n)
                    r = {"circuit": cname, "noise_type": nt, "severity": sev, "trial": trial, **f}
                    r.update({f"p_{s}": v for s, v in pr.items()})
                    rows.append(r)
    df = pd.DataFrame(rows)
    pc = sorted([c for c in df.columns if c.startswith("p_")], key=lambda c: (len(c), c))
    return df[META + ENG + pc].fillna(0.0)

def load(shots, draw):
    """Load a ready-made dataset: shots in SHOTS_LIST, draw in {0,1,2}. 720 rows x 38 columns."""
    return pd.read_csv(DATA / f"s{shots}_d{draw}.csv")

def feat_cols(df, kind="all"):
    raw = [c for c in df.columns if c.startswith("p_")]       # raw outcome probabilities
    return {"all": ENG + raw, "eng": ENG, "raw": raw}[kind]


# =====================================================================
# 5. Classifiers + 5-fold cross-validation
# =====================================================================
def make_model(name, **override):
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.svm import SVC
    from sklearn.neural_network import MLPClassifier
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler
    from sklearn.pipeline import make_pipeline
    import xgboost as xgb
    d = {"RF":  dict(n_estimators=300, random_state=0, n_jobs=1),
         "XGB": dict(n_estimators=300, max_depth=5, random_state=0, eval_metric="mlogloss", n_jobs=1, tree_method="hist"),
         "SVM": dict(kernel="rbf", C=5, gamma="scale"),
         "MLP": dict(hidden_layer_sizes=(64, 32), max_iter=800, random_state=0),
         "LR":  dict(max_iter=1000)}[name]
    p = {**d, **override}
    if name == "RF":  return RandomForestClassifier(**p)
    if name == "XGB": return xgb.XGBClassifier(**p)
    if name == "SVM": return make_pipeline(StandardScaler(), SVC(**p))
    if name == "MLP": return make_pipeline(StandardScaler(), MLPClassifier(**p))
    if name == "LR":  return make_pipeline(StandardScaler(), LogisticRegression(**p))

def labels(df):
    return df["noise_type"].map({n: i for i, n in enumerate(NOISE_TYPES)}).values

def cv_correct(df, model="RF", params=None, seed=0, k=5, feats="all"):
    """k-fold stratified CV. Returns a True/False array: was each row classified correctly?"""
    from sklearn.model_selection import StratifiedKFold, cross_val_predict
    cols = feats if isinstance(feats, list) else feat_cols(df, feats)
    y = labels(df)
    pred = cross_val_predict(make_model(model, **(params or {})), df[cols].values, y,
                             cv=StratifiedKFold(k, shuffle=True, random_state=seed))
    return pred == y

def cv_acc(df, **kw):
    return float(cv_correct(df, **kw).mean())


# =====================================================================
# 6. Print + save a results table (mean +- std of accuracy for each setting)
# =====================================================================
def report(rows, by, name):
    """rows = list of dicts with an 'acc' key; by = column(s) that define a 'setting'."""
    df = pd.DataFrame(rows)
    g = df.groupby(by, sort=False)["acc"].agg(mean=lambda x: 100 * np.mean(x),
                                              std=lambda x: 100 * np.std(x), n="count")
    print(f"\n=== {name} : accuracy % (mean, std over repeats) ===")
    print(g.round(1).to_string())
    g.round(2).to_csv(RES / f"{name}.csv")
    print(f"[saved results/{name}.csv]")
    return g
