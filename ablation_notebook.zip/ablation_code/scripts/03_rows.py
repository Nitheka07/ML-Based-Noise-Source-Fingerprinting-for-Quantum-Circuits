"""
ABLATION 2 - NUMBER OF ROWS (experiments used for training).
Question: how much data do we need?
Method  : pool the 3 datasets at 2048 shots (3 x 720 = 2160 rows). For each size n, draw a random
          sample of n rows that keeps the circuit x noise-type mix equal (stratified), repeat 3 times
          (different random samples), and run 5-fold CV. n = 2160 is the whole pool.
Run:  python 03_rows.py [--quick]
"""
from common import *
pool = pd.concat([load(2048, d) for d in [0, 1, 2]], ignore_index=True)   # always all 3 draws -> 2160 rows

def stratified_sample(df, n, seed):
    per_group = n // 20                                  # 20 groups = 5 circuits x 4 noise types
    return pd.concat([g.sample(per_group, random_state=seed)
                      for _, g in df.groupby(["circuit", "noise_type"])]).reset_index(drop=True)

SIZES = [100, 200, 300, 400, 500, 600, 720, 1080, 1440, 2160]
rows = []
for rep in range(1 if QUICK else 3):
    for n in SIZES:
        df = pool if n == 2160 else stratified_sample(pool, n, rep)
        for m in MODELS:
            rows.append(dict(n_rows=n, model=m, acc=cv_acc(df, model=m, seed=rep)))
report(rows, ["n_rows", "model"], "03_rows")
