"""
ABLATION 6b - JOINT TUNING (small grid search over several hyperparameters together).
Question: if we tune several settings at once, do we beat the default model?
Method  : evaluate every grid combination with 5-fold CV at 2048 shots.
          (draw, CV seeds) pairs follow the original runs: draw0 seed0, draw1 seed0, draw2 seeds 0-2.
Run:  python 09_joint_tuning.py [--quick]
"""
from common import *
GRID = {
 "RF":  {"n_estimators": [100, 300], "max_depth": [8, None], "max_features": ["sqrt", 0.5], "min_samples_leaf": [1, 2]},
 "XGB": {"max_depth": [3, 5, 7], "learning_rate": [0.1, 0.3], "n_estimators": [100, 300]},
 "SVM": {"C": [1, 5, 10, 50], "gamma": ["scale", 0.01, 0.1]},
 "MLP": {"hidden_layer_sizes": [(64,), (64, 32), (128, 64)], "alpha": [1e-4, 1e-2]},
 "LR":  {"C": [0.01, 0.1, 1, 10, 100]},
}
RUNS = [(0, [0])] if QUICK else [(0, [0]), (1, [0]), (2, [0, 1, 2])]
rows = []
for model, grid in GRID.items():
    keys = list(grid)
    for combo in product(*[grid[k] for k in keys]):
        params = dict(zip(keys, combo))
        for d, seeds in RUNS:
            for sd in seeds:
                rows.append(dict(model=model, params=str(params), acc=cv_acc(load(2048, d), model=model, params=params, seed=sd)))
g = report(rows, ["model", "params"], "09_joint_tuning_all_combinations")
best = g.reset_index().sort_values("mean", ascending=False).groupby("model").head(1)
print("\nBest grid setting per model:\n", best.to_string(index=False))
