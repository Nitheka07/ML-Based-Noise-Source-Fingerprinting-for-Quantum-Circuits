"""
ABLATION 5 - CLASSIFIER HYPERPARAMETERS (one at a time).
Question: does tuning a single setting (e.g. SVM's C, number of trees) change accuracy much?
Method  : change ONE hyperparameter, keep all others at default; 5-fold CV, 2048 shots.
Run:  python 07_hyperparameters.py [--quick]     (the slowest script)
"""
from common import *
HP = {
 "RF":  {"n_estimators": [10, 25, 50, 100, 200, 300, 500], "max_depth": [2, 4, 6, 8, 12, None],
         "max_features": ["sqrt", "log2", 0.5, 1.0], "min_samples_split": [2, 4, 8, 16],
         "min_samples_leaf": [1, 2, 4, 8], "criterion": ["gini", "entropy"], "bootstrap": [True, False]},
 "XGB": {"n_estimators": [50, 100, 200, 300, 500], "max_depth": [2, 3, 5, 7, 9],
         "learning_rate": [0.01, 0.03, 0.1, 0.3, 0.5], "subsample": [0.5, 0.8, 1.0], "colsample_bytree": [0.5, 0.8, 1.0]},
 "SVM": {"C": [0.1, 1, 5, 10, 50, 100], "gamma": ["scale", 0.001, 0.01, 0.1, 1], "kernel": ["linear", "poly", "rbf", "sigmoid"]},
 "MLP": {"hidden_layer_sizes": [(16,), (32,), (64,), (64, 32), (128, 64), (128, 64, 32)], "alpha": [1e-5, 1e-4, 1e-3, 1e-2, 1e-1],
         "learning_rate_init": [1e-4, 1e-3, 1e-2], "activation": ["relu", "tanh", "logistic"]},
 "LR":  {"C": [0.001, 0.01, 0.1, 1, 10, 100]},
}
rows = []
for model, params in HP.items():
    for name, values in params.items():
        for v in values:
            for d in DRAWS:
                rows.append(dict(model=model, hyperparameter=name, value=str(v),
                                 acc=cv_acc(load(2048, d), model=model, params={name: v}, seed=0)))
report(rows, ["model", "hyperparameter", "value"], "07_hyperparameters")
