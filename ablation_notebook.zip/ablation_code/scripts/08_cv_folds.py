"""
ABLATION 6a - NUMBER OF CROSS-VALIDATION FOLDS (k = 3, 5, 10).
Question: does the choice of k change the reported accuracy?   2048 shots, all 5 models.
Run:  python 08_cv_folds.py [--quick]
"""
from common import *
rows = []
for k in [3, 5, 10]:
    for m in MODELS:
        for d in DRAWS:
            rows.append(dict(folds=k, model=m, acc=cv_acc(load(2048, d), model=m, seed=0, k=k)))
report(rows, ["folds", "model"], "08_cv_folds")
