"""
MAIN RESULT: can we tell the noise TYPE (4 classes) from measurement counts alone?
Setting : 2048 shots. For each circuit separately, 5-fold CV with each of the 5 classifiers.
Run:  python 01_main_classification.py [--quick]
"""
from common import *
rows = []
for m in MODELS:
    for c in CIRC_ORDER:
        for d in DRAWS:
            for sd in SEEDS:
                df = load(2048, d).query("circuit == @c").reset_index(drop=True)
                rows.append(dict(model=m, circuit=c, acc=cv_acc(df, model=m, seed=sd)))
report(rows, ["model", "circuit"], "01_main_by_model_and_circuit")
report(rows, ["model"], "01_main_by_model")
