"""
OPTIONAL. Regenerates the 36 CSV datasets in datasets/ with Qiskit Aer (takes a long time).
The finished CSVs are already included, so you normally do NOT need to run this.

Dataset size:  5 circuits x 4 noise types x 6 severities x 6 trials = 720 rows each.
36 files = 12 shot settings x 3 independent draws (seeds).
Run:  python 00_generate_datasets.py
"""
from common import *
DATA.mkdir(exist_ok=True)
for draw in range(3):
    for shots in SHOTS_LIST:
        f = DATA / f"s{shots}_d{draw}.csv"
        if f.exists(): continue
        generate_dataset(shots, draw).to_csv(f, index=False); print("wrote", f.name)
