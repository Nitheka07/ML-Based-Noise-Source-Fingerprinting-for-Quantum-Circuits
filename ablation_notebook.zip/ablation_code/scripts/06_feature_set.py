"""
ABLATION 4 - FEATURE SET.
Question: which features carry the information?
Settings: all 34 | engineered only (6) | raw probabilities only (28) |
          drop one engineered feature at a time | use ONE engineered feature alone.   RF, 2048 shots.
Run:  python 06_feature_set.py [--quick]
"""
from common import *
raw = feat_cols(load(2048, 0), "raw")
settings = {"all": ENG + raw, "engineered_only": ENG, "raw_only": raw}
for f in ENG: settings[f"drop_{f}"] = [c for c in ENG + raw if c != f]
for f in ENG: settings[f"only_{f}"] = [f]
rows = []
for name, cols in settings.items():
    for d in DRAWS:
        for sd in SEEDS:
            rows.append(dict(feature_set=name, acc=cv_acc(load(2048, d), model="RF", seed=sd, feats=cols)))
report(rows, ["feature_set"], "06_feature_set")
