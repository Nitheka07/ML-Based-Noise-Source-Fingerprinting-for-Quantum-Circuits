"""
ABLATION 3b - CIRCUIT FAMILY.
(a) Pool size : train+test on the first k circuits only (k = 1..5)  [bell, ghz, w_state, ghz4, bell_pairs].
(b) Transfer  : leave-one-circuit-out (LOCO) - train on 4 circuits, test on the unseen 5th.
RF, 2048 shots.
Run:  python 05_circuit_pool.py [--quick]
"""
from common import *
rows = []
for k in range(1, 6):
    for d in DRAWS:
        for sd in SEEDS:
            df = load(2048, d)[lambda x: x.circuit.isin(CIRC_ORDER[:k])].reset_index(drop=True)
            rows.append(dict(n_circuits=k, acc=cv_acc(df, model="RF", seed=sd)))
report(rows, ["n_circuits"], "05a_circuit_pool_size")

loco = []
for held_out in CIRC_ORDER:
    for kind in ["all", "eng"]:                          # all 34 features vs 6 engineered features
        for d in DRAWS:
            df = load(2048, d); cols = feat_cols(df, kind)
            train, test = df[df.circuit != held_out], df[df.circuit == held_out]
            model = make_model("RF").fit(train[cols].values, labels(train))
            acc = float((model.predict(test[cols].values) == labels(test)).mean())
            loco.append(dict(held_out=held_out, features=kind, acc=acc))
report(loco, ["held_out", "features"], "05b_leave_one_circuit_out")
